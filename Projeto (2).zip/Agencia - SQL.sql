use agencia;

#a) execução da view
select * from v_Passeio_Guia;

#c) comandos procedures
call TotalValorRecebido ("cpf", @valortotal);
select @valortotal;

call ContasAReceber ("data","data");
select @variavel;

#f) (0,5) usuários e privilégios:

#Criar 2 grupos (atendentes e gerentes). 
#Atribuir as permissões de usuário final (CRUD) em todas as tabelas, views e stored procedures para o grupo gerentes. 
#O grupo atendentes tem as mesmas permissões do grupo gerentes, exceto para as stored procedures.


#Criar 5 usuários (nomes a sua escolha, não utilize nomes de usuários já criados em atividades anteriores). 
#Associe 2 usuários ao grupo gerentes e 3 usuários ao grupo atendentes.